Original FROSTORIA winter music is included as Frostoria_Winter_Bells.wav.
The same WAV file is bundled into app/src/main/assets/music/ and packaged into the APK.
Add only original or properly licensed audio files here.
