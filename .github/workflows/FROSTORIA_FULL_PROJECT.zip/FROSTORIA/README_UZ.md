# FROSTORIA — YOUR WINTER WORLD

FROSTORIA — Kotlin + Jetpack Compose asosida yaratilgan Android loyihasi. Ilova ichida aynan 4 ta o‘yin bor:

1. **ELF ADVENTURE** — asosiy tavsiya etilgan o‘yin; original HD Pixel Art elf qahramoni va 4 kadrli sprite animatsiyasi bilan.
2. Santa Run
3. Snowball Fight
4. Snowman Builder

## Loyihani ochish

- ZIP arxivni oching.
- `FROSTORIA` papkasini Android Studio orqali oching.
- Gradle sync tugashini kuting.
- `app` konfiguratsiyasini tanlab, Android qurilma yoki emulator'da ishga tushiring.

## APK yig‘ish (GitHub Actions)

1. `FROSTORIA` papkasidagi barcha fayllarni GitHub repository'ga joylang.
2. GitHub → Actions → **Build FROSTORIA APK** → Run workflow.
3. Build muvaffaqiyatli tugasa, `FROSTORIA-debug-apk` artifact'ini yuklab oling.

## ELF ADVENTURE grafikasi

- `app/src/main/res/drawable-nodpi/elf_hero_idle.png` — asosiy qahramon.
- `elf_hero_run1.png`, `elf_hero_run2.png`, `elf_hero_jump.png` — harakat kadrlar.
- `elf_hero_spritesheet.png` — 4 kadrli sprite sheet.
- O‘yin ekrani qahramonni rasm sifatida ko‘rsatadi; avvalgi emoji belgisi olib tashlandi.
- Konsept rasmlar `docs/previews/` ichida saqlangan.

## Musiqa

Original, ushbu loyiha uchun sintez qilingan qishki kuy `app/src/main/assets/music/Frostoria_Winter_Bells.wav` ichida. Music ekrani MP3, OGG va WAV fayllarini APK ichidagi `assets/music/` papkasidan o‘qiydi. Yangi treklarni shu papkaga qo‘shish mumkin.

## Texnologiya

- Kotlin, Jetpack Compose, Material 3
- Android Gradle Plugin 8.7.3
- Kotlin 2.0.21, Gradle 8.9, JDK 17
- minSdk 23 (Android 6.0), targetSdk 35

## Hozirgi holat

Ushbu ZIP to‘liq loyiha manba kodini, logo va launcher ikonkasini, ELF ADVENTURE pixel-art qahramon sprite'larini, original WAV trekni, to‘rtta o‘yin ekranini va GitHub Actions APK build workflow'ini o‘z ichiga oladi.

Eslatma: mini-o‘yinlar va ELF ADVENTURE hozircha interaktiv prototip darajasida; bu hali yakuniy ishlab chiqarish darajasidagi to‘liq RPG emas. Ushbu muhitda Android SDK/Gradle build vositalari mavjud bo‘lmagani sababli APK bu yerda kompilyatsiya qilinmadi. APK'ni GitHub Actions yoki Android Studio'da build qilib, qurilmada sinash kerak.
