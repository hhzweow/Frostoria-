package com.frostoria.app

import android.inputmethodservice.InputMethodService
import android.view.View
import android.view.inputmethod.InputConnection
import android.widget.Button
import android.widget.LinearLayout

class FrostoriaKeyboardService : InputMethodService() {
    override fun onCreateInputView(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(8, 8, 8, 8)
            setBackgroundColor(0xFFEAF6FF.toInt())
        }
        val rows = listOf(
            listOf("qwertyuiop".toList().map { it.toString() }),
            listOf("asdfghjkl".toList().map { it.toString() }),
            listOf("⇧", "z","x","c","v","b","n","m","⌫"),
            listOf("?123", "❄", "🌟", "English", "space", "↵")
        )
        rows.forEach { row ->
            val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            row.flatten().forEach { key ->
                val b = Button(this).apply {
                    text = key
                    isAllCaps = false
                    setOnClickListener { handleKey(key, currentInputConnection) }
                }
                line.addView(b, LinearLayout.LayoutParams(0, 52, 1f))
            }
            root.addView(line)
        }
        return root
    }
    private fun handleKey(key: String, ic: InputConnection?) {
        when (key) {
            "⌫" -> ic?.deleteSurroundingText(1, 0)
            "↵" -> ic?.commitText("\n", 1)
            "space" -> ic?.commitText(" ", 1)
            "⇧", "?123", "❄", "🌟", "English" -> { }
            else -> ic?.commitText(key, 1)
        }
    }
}
