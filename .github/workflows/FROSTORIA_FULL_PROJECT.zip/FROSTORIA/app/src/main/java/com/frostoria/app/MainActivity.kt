package com.frostoria.app

import android.os.Bundle
import android.content.Intent
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.ui.layout.ContentScale
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.time.LocalDate
import java.time.Duration
import java.time.ZonedDateTime
import java.time.ZoneId
import kotlin.random.Random

private val Ice = Color(0xFFEAF6FF)
private val Blue = Color(0xFF174A78)
private val Silver = Color(0xFFB8CBD9)
private val Deep = Color(0xFF071B36)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FrostoriaApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FrostoriaApp() {
    var tab by remember { mutableStateOf("Home") }
    var language by remember { mutableStateOf("English") }
    var snow by remember { mutableStateOf(true) }
    var snowSpeed by remember { mutableFloatStateOf(1f) }
    var selectedZone by remember { mutableStateOf(ZoneId.systemDefault().id) }
    var activeGame by remember { mutableStateOf<String?>(null) }
    var message by remember { mutableStateOf("") }
    val context = LocalContext.current
    MaterialTheme(colorScheme = lightColorScheme(primary=Blue, secondary=Color(0xFF70BDEB), background=Ice, surface=Color.White)) {
        Scaffold(
            containerColor = Ice,
            topBar = {
                CenterAlignedTopAppBar(
                    title = { Column(horizontalAlignment=Alignment.CenterHorizontally) {
                        Text("FROSTORIA", fontWeight=FontWeight.Black, letterSpacing=3.sp, color=Blue)
                        Text("YOUR WINTER WORLD", fontSize=9.sp, letterSpacing=2.sp, color=Color.Gray)
                    } },
                    colors=TopAppBarDefaults.centerAlignedTopAppBarColors(containerColor=Ice)
                )
            },
            bottomBar = {
                NavigationBar(containerColor=Color.White) {
                    listOf("Home","World","Games","Music","Tools","Settings").forEach { item ->
                        val icon = when(item) {
                            "Home"->Icons.Default.Home; "World"->Icons.Default.AcUnit; "Games"->Icons.Default.SportsEsports
                            "Music"->Icons.Default.MusicNote; "Tools"->Icons.Default.AutoAwesome; else->Icons.Default.Settings
                        }
                        NavigationBarItem(selected=tab==item,onClick={tab=item;activeGame=null},icon={Icon(icon,null)},label={Text(item,fontSize=10.sp)})
                    }
                }
            }
        ) { padding ->
            Box(Modifier.fillMaxSize().padding(padding)) {
                when {
                    activeGame != null -> GameScreen(activeGame!!, onBack={activeGame=null})
                    tab=="Home" -> HomeScreen(onOpen={tab=it}, onGame={activeGame=it}, zone=selectedZone)
                    tab=="World" -> WorldScreen()
                    tab=="Games" -> GamesScreen(onGame={activeGame=it})
                    tab=="Music" -> MusicScreen()
                    tab=="Tools" -> ToolsScreen()
                    else -> SettingsScreen(language, {language=it}, snow, {snow=it}, snowSpeed, {snowSpeed=it}, selectedZone, {selectedZone=it}, message, {message=it})
                }
                if (snow) SnowOverlay(speed=snowSpeed)
            }
        }
    }
}

@Composable
fun SnowOverlay(speed: Float) {
    val flakes = remember { List(34) { Offset(Random.nextFloat(), Random.nextFloat()) } }
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(speed) { while(true) { delay((80 / speed.coerceAtLeast(.3f)).toLong()); tick++ } }
    Canvas(Modifier.fillMaxSize()) {
        flakes.forEachIndexed { i, f ->
            val y = (f.y + tick * (0.0015f + (i%4)*.00035f)) % 1f
            drawCircle(Color.White.copy(alpha=.55f), radius= if(i%5==0) 2.2f else 1.2f, center=Offset(f.x*size.width,y*size.height))
        }
    }
}

@Composable
fun HomeScreen(onOpen:(String)->Unit,onGame:(String)->Unit,zone:String) {
    LazyColumn(Modifier.fillMaxSize().padding(horizontal=16.dp), verticalArrangement=Arrangement.spacedBy(14.dp)) {
        item {
            Card(shape=RoundedCornerShape(28.dp), colors=CardDefaults.cardColors(containerColor=Deep), modifier=Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp)) {
                    Image(painterResource(R.drawable.frostoria_logo), contentDescription="FROSTORIA logo", modifier=Modifier.fillMaxWidth().height(112.dp), contentScale=ContentScale.Fit)
                    Text("❄  WELCOME TO",color=Color(0xFFBFEAFF),fontSize=12.sp,letterSpacing=2.sp)
                    Text("YOUR WINTER\nWORLD",color=Color.White,fontSize=30.sp,fontWeight=FontWeight.Black,lineHeight=34.sp)
                    Text("A little magic in every snowflake.",color=Color(0xFFD7EAF7))
                    Spacer(Modifier.height(12.dp))
                    Text("🎄  Christmas • Games • Music • Magic",color=Color.White,fontSize=12.sp)
                }
            }
        }
        item { CountdownCard() }
        item { Text("FEATURED GAME",fontWeight=FontWeight.Bold,color=Blue,letterSpacing=1.5.sp) }
        item {
            Card(Modifier.fillMaxWidth().clickable { onGame("ELF ADVENTURE: SANTA'S HELPER") }, shape=RoundedCornerShape(22.dp), colors=CardDefaults.cardColors(containerColor=Color.White)) {
                Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically) {
                    Box(Modifier.size(82.dp).background(Color(0xFF173E5E),RoundedCornerShape(18.dp)),contentAlignment=Alignment.Center) {
                        Image(painterResource(R.drawable.elf_hero_idle),contentDescription="ELF ADVENTURE pixel-art hero",modifier=Modifier.size(68.dp,78.dp))
                    }
                    Column(Modifier.weight(1f).padding(start=14.dp)) {
                        Text("RECOMMENDED",color=Color(0xFF1685B8),fontSize=10.sp,fontWeight=FontWeight.Bold)
                        Text("ELF ADVENTURE",fontWeight=FontWeight.ExtraBold,color=Blue,fontSize=18.sp)
                        Text("Santa's Helper • HD Pixel Art",fontSize=12.sp,color=Color.Gray)
                        Text("PLAY NOW  →",fontWeight=FontWeight.Bold,color=Blue,fontSize=12.sp)
                    }
                }
            }
        }
        item { Text("EXPLORE FROSTORIA",fontWeight=FontWeight.Bold,color=Blue,letterSpacing=1.5.sp) }
        items(listOf("World" to "🎄  Christmas World","Games" to "🎮  Four winter games","Music" to "🎵  Winter music player","Tools" to "✨  Planners & creative tools")) { (dest,label) ->
            Card(Modifier.fillMaxWidth().clickable { onOpen(dest) },colors=CardDefaults.cardColors(containerColor=Color.White)) {
                Row(Modifier.padding(17.dp),verticalAlignment=Alignment.CenterVertically) {
                    Text(label,Modifier.weight(1f),fontWeight=FontWeight.SemiBold,color=Blue)
                    Icon(Icons.Default.ChevronRight,null,tint=Blue)
                }
            }
        }
        item { Text("Time zone: $zone",fontSize=11.sp,color=Color.Gray) }
    }
}

@Composable
fun CountdownCard() {
    var now by remember { mutableStateOf(ZonedDateTime.now()) }
    LaunchedEffect(Unit) { while(true) { now=ZonedDateTime.now(); delay(1000) } }
    val target = remember(now.year) { ZonedDateTime.of(now.year+1,1,1,0,0,0,0,now.zone) }
    val diff = Duration.between(now,target).seconds.coerceAtLeast(0)
    Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(22.dp),colors=CardDefaults.cardColors(containerColor=Color(0xFFD6ECFA))) {
        Column(Modifier.padding(18.dp)) {
            Text("✨ COUNTDOWN TO NEW YEAR",fontSize=11.sp,letterSpacing=1.2.sp,color=Blue,fontWeight=FontWeight.Bold)
            Text(String.format("%02d  :  %02d  :  %02d  :  %02d",diff/86400,(diff%86400)/3600,(diff%3600)/60,diff%60),fontSize=25.sp,fontWeight=FontWeight.Black,color=Deep)
            Text("DAYS          HOURS       MINUTES   SECONDS",fontSize=8.sp,color=Blue)
        }
    }
}

@Composable
fun WorldScreen() {
    val worlds=listOf("Christmas World" to "🎄","My Winter City" to "🏙️","Christmas Life" to "🏡","Santa Tracker" to "🛷","Virtual Fireplace" to "🔥","Snow Window" to "❄️","Cozy Room" to "🕯️","Gift Box" to "🎁","Dream Jar" to "✨","Midnight Simulator" to "🌙","Virtual Pet" to "🐧")
    LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
        item { SectionIntro("WINTER WORLDS","Explore cozy places and festive moments.") }
        items(worlds) { (name,emoji)-> FeatureRow(emoji,name,"Open your winter experience") }
    }
}
@Composable
fun GamesScreen(onGame:(String)->Unit) {
    val games=listOf("ELF ADVENTURE: SANTA'S HELPER" to "🧝","Santa Run" to "🎅","Snowball Fight" to "❄️","Snowman Builder" to "⛄")
    LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
        item { SectionIntro("FOUR WINTER GAMES","Choose a game and start playing.") }
        items(games) { (name,emoji)->
            Card(Modifier.fillMaxWidth().clickable { onGame(name) },colors=CardDefaults.cardColors(containerColor=Color.White),shape=RoundedCornerShape(20.dp)) {
                Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically) {
                    Text(emoji,fontSize=36.sp); Column(Modifier.weight(1f).padding(start=14.dp)) { Text(name,fontWeight=FontWeight.Bold,color=Blue); Text(if(name.startsWith("ELF")) "Recommended • HD Pixel Art RPG" else "Winter mini-game",fontSize=12.sp,color=Color.Gray) }
                    Icon(Icons.Default.PlayCircle,null,tint=Blue)
                }
            }
        }
    }
}
@Composable
fun GameScreen(name:String,onBack:()->Unit) {
    var score by remember { mutableIntStateOf(0) }
    var lives by remember { mutableIntStateOf(3) }
    var stage by remember { mutableIntStateOf(1) }
    var status by remember { mutableStateOf("Ready for an adventure?") }
    var parts by remember { mutableIntStateOf(0) }
    var finished by remember { mutableStateOf(false) }
    var elfFrame by remember { mutableIntStateOf(0) }
    val elf=name.startsWith("ELF"); val run=name=="Santa Run"
    LaunchedEffect(elf) { if (elf) { while (true) { elfFrame = if (elfFrame == 1) 3 else 1; delay(190) } } }
    val snowball=name=="Snowball Fight"; val snowman=name=="Snowman Builder"
    Column(Modifier.fillMaxSize().padding(16.dp),horizontalAlignment=Alignment.CenterHorizontally) {
        Row(verticalAlignment=Alignment.CenterVertically) { TextButton(onClick=onBack) { Text("← BACK") }; Text(name,Modifier.weight(1f),fontWeight=FontWeight.Bold,color=Blue) }
        Card(Modifier.fillMaxWidth().weight(1f),colors=CardDefaults.cardColors(containerColor=Color(0xFF102E4B)),shape=RoundedCornerShape(22.dp)) {
            Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center) {
                Canvas(Modifier.fillMaxSize()) {
                    // Moonlit pixel-winter sky and distant mountains
                    drawCircle(Color(0xFFFFF2C7).copy(alpha=.8f), size.minDimension*.075f, Offset(size.width*.78f,size.height*.18f))
                    for(i in 0..35) drawCircle(Color.White.copy(alpha=.75f), if(i%4==0) 2.4f else 1.3f, Offset((i*83f)%size.width,(i*137f)%size.height*.68f))
                    val hill=Path().apply { moveTo(0f,size.height*.62f); lineTo(size.width*.18f,size.height*.35f); lineTo(size.width*.34f,size.height*.61f); lineTo(size.width*.55f,size.height*.3f); lineTo(size.width*.78f,size.height*.6f); lineTo(size.width,size.height*.4f); lineTo(size.width,size.height); lineTo(0f,size.height); close() }
                    drawPath(hill,Color(0xFF315C86))
                    drawRect(Color(0xFF244F69),topLeft=Offset(0f,size.height*.78f),size=androidx.compose.ui.geometry.Size(size.width,size.height*.22f))
                    drawRect(Color(0xFFEAF8FF),topLeft=Offset(0f,size.height*.765f),size=androidx.compose.ui.geometry.Size(size.width,size.height*.035f))
                    // Floating gold coins
                    for(i in 0..3) { val x=size.width*(.28f+i*.12f); val y=size.height*(.53f-(i%2)*.07f); drawCircle(Color(0xFFFFC84D),size.minDimension*.022f,Offset(x,y)); drawCircle(Color(0xFFFFF0A8),size.minDimension*.012f,Offset(x,y)) }
                    // Small snow-covered platform
                    drawRect(Color(0xFFB9E5FA),Offset(size.width*.68f,size.height*.68f),androidx.compose.ui.geometry.Size(size.width*.24f,size.height*.1f))
                    drawRect(Color.White,Offset(size.width*.68f,size.height*.66f),androidx.compose.ui.geometry.Size(size.width*.24f,size.height*.035f))
                }
                Column(horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(7.dp)) {
                    if (elf) Image(painterResource(when(elfFrame){1->R.drawable.elf_hero_run1;3->R.drawable.elf_hero_run2;2->R.drawable.elf_hero_jump;else->R.drawable.elf_hero_idle}), contentDescription="Pixel-art winter elf hero", modifier=Modifier.size(112.dp,140.dp))
                    else Text(if(run) "🎅" else if(snowball) "❄️" else "⛄",fontSize=68.sp)
                    Text(if(elf) "ELF ADVENTURE" else name.uppercase(),color=Color.White,fontWeight=FontWeight.Black,fontSize=20.sp)
                    Text("Score: $score     ❤️ $lives",color=Color(0xFFBFEAFF),fontWeight=FontWeight.Bold)
                    Text(status,color=Color.White,fontSize=13.sp)
                    if(elf) Text("WORLD 1 • QUEST $stage / 5",color=Color.White,fontSize=12.sp,fontWeight=FontWeight.Bold)
                    if(snowman) Text("Snowman pieces: $parts / 3",color=Color.White)
                    if(finished) Text("🎉 LEVEL COMPLETE!",color=Color(0xFFFFE7A6),fontWeight=FontWeight.Black)
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        when {
            elf -> {
                Text("QUEST: Explore the snowy path and collect 5 gifts.",color=Blue,fontWeight=FontWeight.SemiBold)
                Row(horizontalArrangement=Arrangement.spacedBy(7.dp)) {
                    OutlinedButton(onClick={status="You moved left along the snowy path."}) { Text("◀") }
                    OutlinedButton(onClick={status="You moved right along the snowy path."}) { Text("▶") }
                    Button(onClick={if(!finished){score++;stage++;status="✨ Gift collected! +1";if(stage>5){finished=true;status="All five gifts delivered!"}}}) { Text("🎁 COLLECT") }
                    OutlinedButton(onClick={if(!finished){status="⬆ Nice jump over the ice!";elfFrame=2}}) { Text("⬆ JUMP") }
                }
            }
            run -> Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                Button(onClick={if(!finished){score++;status="Great jump! You avoided the snowdrift."}}) { Text("⬆ JUMP") }
                Button(onClick={if(!finished){if(Random.nextBoolean()){score+=2;status="Gift collected!"}else{lives--;status="Snowbank!";if(lives<=0)finished=true}}}) { Text("🎁 COLLECT") }
                OutlinedButton(onClick={if(!finished){lives--;status="Obstacle!";if(lives<=0)finished=true}}) { Text("DODGE") }
            }
            snowball -> Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                Button(onClick={if(!finished){score++;status="Direct hit! +1 point"}}) { Text("❄ THROW") }
                OutlinedButton(onClick={status="You hid behind a snow fort."}) { Text("🛡 DEFEND") }
                OutlinedButton(onClick={if(!finished){score+=2;status="Perfect aim! +2"}}) { Text("🎯 AIM") }
            }
            snowman -> Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                Button(onClick={if(parts<3){parts++;status=listOf("Base made!","Middle snowball added!","Snowman complete!")[parts-1];if(parts==3){score+=10;finished=true}}}) { Text("➕ ADD SNOW") }
                OutlinedButton(onClick={if(parts==3)status="Choose a scarf and enjoy your snowman!" else status="Build the three snowballs first."}) { Text("🧣 DECORATE") }
            }
        }
        if(finished) TextButton(onClick={score=0;lives=3;stage=1;parts=0;finished=false;status="Ready for an adventure?"}) { Text("PLAY AGAIN") }
    }
}

@Composable
fun MusicScreen() {
    val context = LocalContext.current
    val tracks = remember {
        try { context.assets.list("music")?.filter { it.endsWith(".mp3", true) || it.endsWith(".ogg", true) || it.endsWith(".wav", true) } ?: emptyList() }
        catch (_: Exception) { emptyList() }
    }
    var player by remember { mutableStateOf<android.media.MediaPlayer?>(null) }
    var current by remember { mutableIntStateOf(-1) }
    var playing by remember { mutableStateOf(false) }
    var volume by remember { mutableFloatStateOf(.75f) }
    fun playTrack(index: Int) {
        try {
            player?.release()
            val mp = android.media.MediaPlayer()
            val cached = java.io.File(context.cacheDir, tracks[index])
            context.assets.open("music/${tracks[index]}").use { input ->
                cached.outputStream().use { output -> input.copyTo(output) }
            }
            mp.setDataSource(cached.absolutePath)
            mp.setOnCompletionListener { playing = false }
            mp.setVolume(volume, volume); mp.prepare(); mp.start()
            player = mp; current = index; playing = true
        } catch (_: Exception) { playing = false }
    }
    DisposableEffect(Unit) { onDispose { player?.release(); player = null } }
    Column(Modifier.fillMaxSize().padding(18.dp),verticalArrangement=Arrangement.spacedBy(14.dp)) {
        SectionIntro("WINTER MUSIC","Your own soundtrack, stored locally inside the app.")
        Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=Deep),shape=RoundedCornerShape(24.dp)) {
            Column(Modifier.padding(20.dp)) {
                Text("❄️  FROSTORIA RADIO",color=Color(0xFFBFEAFF),fontWeight=FontWeight.Bold)
                Text(if(current>=0) tracks[current] else "A cozy winter soundtrack",color=Color.White,fontSize=19.sp,fontWeight=FontWeight.Bold)
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment=Alignment.CenterVertically) {
                    IconButton(onClick={ if(current<0 && tracks.isNotEmpty()) playTrack(0) else if(playing) { player?.pause(); playing=false } else { player?.start(); playing=true } },enabled=tracks.isNotEmpty()) {
                        Icon(if(playing) Icons.Default.Pause else Icons.Default.PlayArrow,null,tint=Color.White)
                    }
                    Text(if(tracks.isEmpty()) "No tracks added yet" else if(playing) "Now playing" else "Paused",color=Color.White)
                }
            }
        }
        Text("VOLUME",fontWeight=FontWeight.Bold,color=Blue)
        Slider(value=volume,onValueChange={volume=it;player?.setVolume(it,it)})
        Text("LOCAL PLAYLIST (${tracks.size})",fontWeight=FontWeight.Bold,color=Blue)
        if(tracks.isEmpty()) Text("Add MP3, OGG or WAV files to app/src/main/assets/music/ and rebuild the APK.",color=Color.Gray,fontSize=13.sp)
        tracks.forEachIndexed { index, track ->
            Card(Modifier.fillMaxWidth().clickable { playTrack(index) },colors=CardDefaults.cardColors(containerColor=Color.White)) {
                Row(Modifier.padding(12.dp),verticalAlignment=Alignment.CenterVertically) {
                    Icon(Icons.Default.MusicNote,null,tint=Blue)
                    Text(track,Modifier.weight(1f).padding(start=10.dp),color=Blue)
                    Icon(if(current==index && playing) Icons.Default.GraphicEq else Icons.Default.PlayArrow,null,tint=Blue)
                }
            }
        }
        Text("Only add audio you created or have permission to distribute.",fontSize=11.sp,color=Color.Gray)
    }
}

@Composable
fun ToolsScreen() {
    val tools=listOf("Gift Planner" to "🎁","Secret Santa" to "🎅","Wish List" to "⭐","Letter to Santa" to "✉️","Daily Challenges" to "🏆","Christmas Piano" to "🎹","Music Box" to "🎼","Diary" to "📔","Future Me 2027" to "💌","Fortune Messages" to "🔮","New Year Social" to "🎉","Photo Studio" to "📸","Snow Camera" to "📷","Wallpapers" to "🖼️")
    LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(9.dp)) {
        item { SectionIntro("WINTER TOOLBOX","Plan, create, save memories and celebrate.") }
        items(tools) { (name,emoji)-> FeatureRow(emoji,name,"Your personal winter toolkit") }
    }
}
@Composable
fun SettingsScreen(language:String,setLanguage:(String)->Unit,snow:Boolean,setSnow:(Boolean)->Unit,speed:Float,setSpeed:(Float)->Unit,zone:String,setZone:(String)->Unit,message:String,setMessage:(String)->Unit) {
    val context=LocalContext.current
    LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
        item { SectionIntro("SETTINGS","Make FROSTORIA feel like your winter world.") }
        item {
            Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                Button(onClick={message="Add your official Telegram URL in project configuration."},modifier=Modifier.weight(1f)) { Icon(Icons.Default.Send,null); Text(" Telegram") }
                OutlinedButton(onClick={message="Add your official Instagram URL in project configuration."},modifier=Modifier.weight(1f)) { Icon(Icons.Default.CameraAlt,null); Text(" Instagram") }
            }
        }
        item {
            Card(colors=CardDefaults.cardColors(containerColor=Color.White)) {
                Column(Modifier.padding(16.dp)) {
                    Text("LANGUAGE",fontWeight=FontWeight.Bold,color=Blue)
                    var expanded by remember { mutableStateOf(false) }
                    Box {
                        OutlinedButton(onClick={expanded=true}) { Text(language) }
                        DropdownMenu(expanded=expanded,onDismissRequest={expanded=false}) {
                            listOf("English","Русский","O‘zbekcha","Français","Deutsch","Italiano").forEach { DropdownMenuItem(text={Text(it)},onClick={setLanguage(it);expanded=false}) }
                        }
                    }
                }
            }
        }
        item {
            Card(colors=CardDefaults.cardColors(containerColor=Color.White)) {
                Column(Modifier.padding(16.dp)) {
                    Text("TIME ZONE",fontWeight=FontWeight.Bold,color=Blue)
                    Text(zone,fontSize=13.sp,color=Color.Gray)
                    OutlinedButton(onClick={setZone(ZoneId.systemDefault().id)}) { Text("Use device time zone") }
                }
            }
        }
        item {
            Card(colors=CardDefaults.cardColors(containerColor=Color.White)) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment=Alignment.CenterVertically) { Text("SNOW EFFECTS",Modifier.weight(1f),fontWeight=FontWeight.Bold,color=Blue); Switch(checked=snow,onCheckedChange=setSnow) }
                    Text("Snow speed",fontSize=12.sp)
                    Slider(value=speed,onValueChange=setSpeed,valueRange=.3f..2.5f,enabled=snow)
                }
            }
        }
        item { FeatureRow("⌨️","FROSTORIA Keyboard","Enable it in Android Settings → Languages & input.") }
        item { Button(onClick={context.startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))},modifier=Modifier.fillMaxWidth()) { Text("OPEN KEYBOARD SETTINGS") } }
        item { Text("Privacy: the keyboard does not send typed text over the internet. This project requests no internet permission.",fontSize=12.sp,color=Color.Gray) }
        item { Text(message,color=Blue,fontSize=12.sp) }
        item { Text("FROSTORIA • YOUR WINTER WORLD • Version 1.0.0",fontSize=11.sp,color=Color.Gray) }
    }
}
@Composable
fun SectionIntro(title:String,subtitle:String) {
    Column(Modifier.padding(bottom=4.dp)) { Text(title,color=Blue,fontSize=21.sp,fontWeight=FontWeight.Black,letterSpacing=1.sp); Text(subtitle,color=Color.Gray,fontSize=12.sp) }
}
@Composable
fun FeatureRow(emoji:String,title:String,subtitle:String) {
    Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=Color.White),shape=RoundedCornerShape(18.dp)) {
        Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically) {
            Text(emoji,fontSize=27.sp)
            Column(Modifier.padding(start=12.dp)) { Text(title,color=Blue,fontWeight=FontWeight.Bold); Text(subtitle,color=Color.Gray,fontSize=11.sp) }
        }
    }
}
